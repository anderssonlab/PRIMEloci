gr_list <- run_PRIMEloci_workflow(ctss_rse = ctss_rse[, "K562_C3"],
                                  tc_grl = tc_grl$K562_C3,
                                  config_file = "config_PRIMEloci.yaml")
                                  