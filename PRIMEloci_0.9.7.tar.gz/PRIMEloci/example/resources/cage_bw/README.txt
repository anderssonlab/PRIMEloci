Copy bw files

cp /maps/projects/ralab/data/projects/nucleiCAGEproject/8.Genomewide_prediction/example_cage_K562_bw/* .