from setuptools import setup, find_packages
import os

setup(
    name='pyPRIMEloci',
    version='0.1.0',
    packages=find_packages(),
    install_requires=[
        'matplotlib',
        'numpy',
        'pandas',
        'seaborn',
        'lightgbm',
        'scikit-learn'
    ],
    entry_points={
        'console_scripts': [
            # Define any command-line scripts here, e.g., 'script_name=module:function_name'
        ],
    },
    author='Natsuda Navamajiti',
    author_email='natsuda@bio.ku.dk',
    description='A brief description of your library',
    long_description=open('README.md').read() if os.path.exists('README.md') else '',
    long_description_content_type='text/markdown',
    url='https://github.com/yourusername/my_library', # will be updated
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',  # Specify the Python versions supported
)
